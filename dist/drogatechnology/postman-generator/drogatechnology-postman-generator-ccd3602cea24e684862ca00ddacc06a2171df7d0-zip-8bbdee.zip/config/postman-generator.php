<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Collection name
    |--------------------------------------------------------------------------
    | Defaults to "<App Name> API" when null.
    */
    'name' => null,

    /*
    |--------------------------------------------------------------------------
    | Output paths (relative to base_path unless absolute)
    |--------------------------------------------------------------------------
    */
    'output' => [
        'collection' => 'postman/collection.json',
        'environment' => 'postman/environment.json',
    ],

    /*
    |--------------------------------------------------------------------------
    | Route filtering
    |--------------------------------------------------------------------------
    | 'only' / 'except' accept URI patterns matched with Str::is() (wildcards
    | allowed, e.g. "api/*"). 'except_middleware' skips any route that has
    | one of the given middleware (exact name match, e.g. "throttle").
    | 'except_name' skips routes whose name matches (wildcards allowed).
    */
    'routes' => [
        'only' => ['api/*'],
        'except' => [],
        'except_name' => [],
        'except_middleware' => [],
        'include_head' => false,
    ],

    /*
    |--------------------------------------------------------------------------
    | Grouping strategy
    |--------------------------------------------------------------------------
    | 'prefix'     -> group by first URI segment after the matched "only" root
    | 'controller' -> group by controller class (short name)
    | 'none'       -> flat list, no folders
    */
    'grouping' => 'prefix',

    /*
    |--------------------------------------------------------------------------
    | Base URL variable
    |--------------------------------------------------------------------------
    | Written into both the collection ("variable") and the generated
    | environment file. Reference it in requests as {{base_url}}.
    */
    'base_url' => env('APP_URL', 'http://localhost'),

    /*
    |--------------------------------------------------------------------------
    | Authentication
    |--------------------------------------------------------------------------
    | Maps Laravel auth middleware to a Postman auth type. A route carrying
    | one of these middleware gets that auth block; otherwise 'default' is
    | used. Set a mapping to null to explicitly mark routes as noauth.
    |
    | Supported Postman types here: 'bearer', 'basic', 'apikey', 'noauth'.
    */
    'auth' => [
        'default' => 'noauth',

        'middleware_map' => [
            'auth:sanctum' => 'bearer',
            'auth:api' => 'bearer',
            'auth' => 'bearer',
            'auth:basic' => 'basic',
        ],

        // Variable name used for the bearer token, referenced as {{token}}
        'bearer_variable' => 'token',

        // Used when auth type resolves to 'apikey'
        'apikey' => [
            'key' => 'X-API-Key',
            'variable' => 'api_key',
            'in' => 'header', // header|query
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Default headers
    |--------------------------------------------------------------------------
    | Applied to every request, in addition to any auth header.
    */
    'headers' => [
        ['key' => 'Accept', 'value' => 'application/json'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Body inference
    |--------------------------------------------------------------------------
    | When true, the generator reflects on FormRequest::rules() (or an
    | inline closure's type-hinted FormRequest) to build a sample JSON body
    | with placeholder values matching the validation rule types.
    */
    'infer_body_from_form_requests' => true,

    /*
    |--------------------------------------------------------------------------
    | Environment variables
    |--------------------------------------------------------------------------
    | Extra key/value pairs written into the generated Postman environment
    | file alongside base_url and the auth token/apikey placeholders.
    */
    'environment_variables' => [
        // 'tenant_id' => '',
    ],
];
