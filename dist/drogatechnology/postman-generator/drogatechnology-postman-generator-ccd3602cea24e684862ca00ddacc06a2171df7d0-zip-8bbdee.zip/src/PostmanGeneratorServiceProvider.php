<?php

namespace DrogaTechnology\PostmanGenerator;

use Illuminate\Support\ServiceProvider;
use DrogaTechnology\PostmanGenerator\Console\GeneratePostmanCollection;

class PostmanGeneratorServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/postman-generator.php', 'postman-generator');
    }

    public function boot(): void
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                GeneratePostmanCollection::class,
            ]);

            $this->publishes([
                __DIR__ . '/../config/postman-generator.php' => config_path('postman-generator.php'),
            ], 'postman-generator-config');
        }
    }
}
