<?php

namespace DrogaTechnology\PostmanGenerator\Generator;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Routing\Route as RouteObj;
use Illuminate\Support\Str;
use ReflectionFunction;
use ReflectionMethod;
use ReflectionNamedType;

class CollectionBuilder
{
    protected RuleSampler $sampler;
    protected AuthResolver $authResolver;
    protected array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
        $this->sampler = new RuleSampler();
        $this->authResolver = new AuthResolver($config['auth'] ?? []);
    }

    /**
     * @param RouteObj[] $routes
     */
    public function build(iterable $routes, string $appName): array
    {
        $items = [];
        foreach ($routes as $route) {
            $items[] = $this->routeToItem($route);
        }

        return [
            'info' => [
                'name' => $this->config['name'] ?? ($appName . ' API'),
                '_postman_id' => $this->uuid(),
                'schema' => 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json',
            ],
            'item' => $this->group($items),
            'auth' => $this->authResolver->resolve([])['type'] === 'noauth'
                ? null
                : $this->authResolver->resolve([]),
            'variable' => array_merge(
                [['key' => 'base_url', 'value' => rtrim($this->config['base_url'], '/')]],
                $this->authVariables()
            ),
        ];
    }

    public function buildEnvironment(string $appName): array
    {
        $values = array_merge(
            ['base_url' => rtrim($this->config['base_url'], '/')],
            $this->authEnvironmentDefaults(),
            $this->config['environment_variables'] ?? []
        );

        return [
            'id' => $this->uuid(),
            'name' => $this->config['name'] ?? ($appName . ' API') . ' Environment',
            'values' => collect($values)->map(fn ($value, $key) => [
                'key' => $key,
                'value' => (string) $value,
                'type' => 'default',
                'enabled' => true,
            ])->values()->all(),
            '_postman_variable_scope' => 'environment',
        ];
    }

    protected function authVariables(): array
    {
        $vars = [];
        $bearerVar = $this->config['auth']['bearer_variable'] ?? 'token';
        $vars[] = ['key' => $bearerVar, 'value' => ''];
        return $vars;
    }

    protected function authEnvironmentDefaults(): array
    {
        return [
            ($this->config['auth']['bearer_variable'] ?? 'token') => '',
        ];
    }

    protected function routeToItem(RouteObj $route): array
    {
        $methods = array_values(array_diff($route->methods(), $this->config['routes']['include_head'] ? [] : ['HEAD']));
        $method = $methods[0] ?? 'GET';
        $uri = $route->uri();

        $pathVars = [];
        $postmanUri = preg_replace_callback('/\{(\w+)\??\}/', function ($m) use (&$pathVars) {
            $pathVars[] = $m[1];
            return ':' . $m[1];
        }, $uri);

        $segments = array_values(array_filter(explode('/', $postmanUri), fn ($s) => $s !== ''));

        $middleware = array_values(array_map(
            fn ($m) => is_string($m) ? $m : (string) $m,
            $route->gatherMiddleware()
        ));

        $header = array_merge($this->config['headers'] ?? [], $this->methodBodyHeader($method));

        $bodyRules = $this->config['infer_body_from_form_requests'] ?? true
            ? $this->extractFormRequestRules($route)
            : null;

        $body = null;
        if (in_array($method, ['POST', 'PUT', 'PATCH'], true)) {
            $sample = $bodyRules ? $this->sampler->build($bodyRules) : new \stdClass();
            $body = [
                'mode' => 'raw',
                'raw' => json_encode($sample ?: new \stdClass(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
                'options' => ['raw' => ['language' => 'json']],
            ];
        }

        return [
            'name' => $route->getName() ?? ($method . ' /' . $uri),
            '_controller_group' => $this->controllerGroupName($route),
            'request' => array_filter([
                'method' => $method,
                'header' => $header,
                'auth' => $this->authResolver->resolve($middleware),
                'url' => [
                    'raw' => '{{base_url}}/' . $postmanUri,
                    'host' => ['{{base_url}}'],
                    'path' => $segments,
                    'variable' => array_map(fn ($v) => ['key' => $v, 'value' => ''], $pathVars),
                ],
                'body' => $body,
            ], fn ($v) => $v !== null),
            'response' => [],
        ];
    }

    protected function controllerGroupName(RouteObj $route): string
    {
        $action = $route->getAction();

        if (isset($action['controller']) && is_string($action['controller'])) {
            $class = explode('@', $action['controller'])[0];
            return Str::of(class_basename($class))->replace('Controller', '')->value() ?: 'Misc';
        }

        return 'Closures';
    }

    protected function methodBodyHeader(string $method): array
    {
        return in_array($method, ['POST', 'PUT', 'PATCH'], true)
            ? [['key' => 'Content-Type', 'value' => 'application/json']]
            : [];
    }

    /**
     * Reflects the route's controller method (or closure) to find a
     * type-hinted FormRequest parameter, and returns its rules().
     */
    protected function extractFormRequestRules(RouteObj $route): ?array
    {
        try {
            $action = $route->getAction();

            if (isset($action['uses']) && is_string($action['uses']) && str_contains($action['uses'], '@')) {
                [$class, $method] = explode('@', $action['uses']);
                if (!class_exists($class) || !method_exists($class, $method)) {
                    return null;
                }
                $reflection = new ReflectionMethod($class, $method);
            } elseif (isset($action['uses']) && $action['uses'] instanceof \Closure) {
                $reflection = new ReflectionFunction($action['uses']);
            } else {
                return null;
            }

            foreach ($reflection->getParameters() as $param) {
                $type = $param->getType();
                if (!$type instanceof ReflectionNamedType || $type->isBuiltin()) {
                    continue;
                }

                $typeName = $type->getName();
                if (is_a($typeName, FormRequest::class, true)) {
                    /** @var FormRequest $instance */
                    $instance = new $typeName();
                    if (method_exists($instance, 'rules')) {
                        $rules = $instance->rules();
                        return is_array($rules) ? $rules : null;
                    }
                }
            }
        } catch (\Throwable $e) {
            return null;
        }

        return null;
    }

    protected function group(array $items): array
    {
        $strategy = $this->config['grouping'] ?? 'prefix';

        if ($strategy === 'none') {
            return array_map(function ($item) {
                unset($item['_controller_group']);
                return $item;
            }, $items);
        }

        $groups = [];
        foreach ($items as $item) {
            $key = $strategy === 'controller'
                ? ($item['_controller_group'] ?? 'Misc')
                : $this->prefixGroupKey($item);

            unset($item['_controller_group']);
            $groups[$key][] = $item;
        }

        return collect($groups)->map(fn ($groupItems, $name) => [
            'name' => Str::title(str_replace(['-', '_'], ' ', $name)),
            'item' => $groupItems,
        ])->values()->all();
    }

    protected function prefixGroupKey(array $item): string
    {
        $path = $item['request']['url']['path'] ?? [];
        return $path[0] ?? 'root';
    }

    protected function uuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}
