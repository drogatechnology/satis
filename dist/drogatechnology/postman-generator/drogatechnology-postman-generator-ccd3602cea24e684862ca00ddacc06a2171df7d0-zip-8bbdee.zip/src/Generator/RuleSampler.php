<?php

namespace DrogaTechnology\PostmanGenerator\Generator;

/**
 * Turns a FormRequest::rules() array into a sample body payload,
 * so the generated request already has plausible placeholder JSON
 * instead of an empty {}.
 */
class RuleSampler
{
    public function build(array $rules): array
    {
        $sample = [];

        foreach ($rules as $field => $ruleset) {
            // skip wildcard/nested array rules like "items.*.name" at the top level;
            // they're handled when we hit their parent "items" key.
            if (str_contains($field, '.*')) {
                continue;
            }

            $ruleList = $this->normalizeRules($ruleset);
            $value = $this->sampleFor($field, $ruleList, $rules);

            $this->setDotted($sample, $field, $value);
        }

        return $sample;
    }

    protected function normalizeRules($ruleset): array
    {
        if (is_string($ruleset)) {
            return explode('|', $ruleset);
        }

        // could be an array mixing strings and Rule objects
        $flat = [];
        foreach ((array) $ruleset as $rule) {
            if (is_string($rule)) {
                array_push($flat, ...explode('|', $rule));
            } elseif (is_object($rule)) {
                $flat[] = class_basename($rule);
            }
        }

        return $flat;
    }

    protected function sampleFor(string $field, array $ruleList, array $allRules)
    {
        $ruleNames = array_map(fn ($r) => is_string($r) ? strtolower(explode(':', $r)[0]) : '', $ruleList);

        if (in_array('array', $ruleNames)) {
            $itemKey = $field . '.*';
            if (isset($allRules[$itemKey])) {
                $itemRules = $this->normalizeRules($allRules[$itemKey]);
                return [$this->sampleFor($field . '.*', $itemRules, $allRules)];
            }
            return [];
        }

        foreach ($ruleList as $rule) {
            if (!is_string($rule)) {
                continue;
            }
            [$name, $param] = array_pad(explode(':', $rule, 2), 2, null);
            $name = strtolower($name);

            switch ($name) {
                case 'boolean':
                    return true;
                case 'integer':
                    return 1;
                case 'numeric':
                case 'decimal':
                    return 1.5;
                case 'email':
                    return 'user@example.com';
                case 'url':
                    return 'https://example.com';
                case 'date':
                case 'date_format':
                    return now_placeholder();
                case 'in':
                    return $param ? explode(',', $param)[0] : 'value';
                case 'uuid':
                    return '00000000-0000-0000-0000-000000000000';
                case 'exists':
                case 'file':
                case 'image':
                    return 1;
            }
        }

        return $this->guessByFieldName($field);
    }

    protected function guessByFieldName(string $field)
    {
        $leaf = last(explode('.', str_replace('.*', '', $field)));

        return match (true) {
            $leaf === 'id' || str_ends_with($leaf, '_id') => 1,
            str_contains($leaf, 'email') => 'user@example.com',
            str_contains($leaf, 'password') => 'secret123',
            str_contains($leaf, 'name') => 'Example ' . ucfirst($leaf),
            str_contains($leaf, 'url') => 'https://example.com',
            str_contains($leaf, 'phone') => '+1234567890',
            str_contains($leaf, 'date') => '2025-01-01',
            str_contains($leaf, 'amount') || str_contains($leaf, 'price') => 100,
            default => 'sample',
        };
    }

    protected function setDotted(array &$target, string $field, $value): void
    {
        $field = str_replace('.*', '', $field);
        $segments = explode('.', $field);
        $cursor = &$target;

        foreach ($segments as $i => $segment) {
            $isLast = $i === count($segments) - 1;
            if ($isLast) {
                $cursor[$segment] = $value;
            } else {
                $cursor[$segment] = $cursor[$segment] ?? [];
                $cursor = &$cursor[$segment];
            }
        }
    }
}

if (!function_exists('DrogaTechnology\PostmanGenerator\Generator\now_placeholder')) {
    function now_placeholder(): string
    {
        return date('Y-m-d');
    }
}
