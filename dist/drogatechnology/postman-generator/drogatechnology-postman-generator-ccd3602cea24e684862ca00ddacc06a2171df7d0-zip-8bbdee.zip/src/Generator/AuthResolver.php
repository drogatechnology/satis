<?php

namespace DrogaTechnology\PostmanGenerator\Generator;

class AuthResolver
{
    protected array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * @param string[] $middleware Flat list of middleware strings/aliases for the route
     */
    public function resolve(array $middleware): array
    {
        $map = $this->config['middleware_map'] ?? [];

        foreach ($middleware as $m) {
            if (array_key_exists($m, $map)) {
                return $this->build($map[$m]);
            }
            // also match by prefix, e.g. "auth" matching "auth:sanctum"
            foreach ($map as $pattern => $type) {
                if (str_starts_with($m, $pattern)) {
                    return $this->build($type);
                }
            }
        }

        return $this->build($this->config['default'] ?? 'noauth');
    }

    protected function build(?string $type): array
    {
        return match ($type) {
            'bearer' => [
                'type' => 'bearer',
                'bearer' => [
                    ['key' => 'token', 'value' => '{{' . ($this->config['bearer_variable'] ?? 'token') . '}}', 'type' => 'string'],
                ],
            ],
            'basic' => [
                'type' => 'basic',
                'basic' => [
                    ['key' => 'username', 'value' => '{{basic_username}}', 'type' => 'string'],
                    ['key' => 'password', 'value' => '{{basic_password}}', 'type' => 'string'],
                ],
            ],
            'apikey' => [
                'type' => 'apikey',
                'apikey' => [
                    ['key' => 'key', 'value' => $this->config['apikey']['key'] ?? 'X-API-Key', 'type' => 'string'],
                    ['key' => 'value', 'value' => '{{' . ($this->config['apikey']['variable'] ?? 'api_key') . '}}', 'type' => 'string'],
                    ['key' => 'in', 'value' => $this->config['apikey']['in'] ?? 'header', 'type' => 'string'],
                ],
            ],
            default => ['type' => 'noauth'],
        };
    }
}
