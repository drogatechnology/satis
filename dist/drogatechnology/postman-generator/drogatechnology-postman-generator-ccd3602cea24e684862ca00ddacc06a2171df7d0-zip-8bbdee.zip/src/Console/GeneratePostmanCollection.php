<?php

namespace DrogaTechnology\PostmanGenerator\Console;

use Illuminate\Console\Command;
use Illuminate\Routing\Route as RouteObj;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use DrogaTechnology\PostmanGenerator\Generator\CollectionBuilder;

class GeneratePostmanCollection extends Command
{
    protected $signature = 'postman:generate
                            {--only=* : Override config route.only patterns (e.g. api/*)}
                            {--except=* : Override config route.except patterns}
                            {--no-env : Skip generating the environment file}
                            {--output= : Override the collection output path}';

    protected $description = 'Generate a Postman collection (and environment) from the application\'s routes';

    public function handle(): int
    {
        $config = config('postman-generator');

        $only = $this->option('only') ?: ($config['routes']['only'] ?? []);
        $except = $this->option('except') ?: ($config['routes']['except'] ?? []);

        $routes = collect(Route::getRoutes())
            ->filter(fn (RouteObj $route) => $this->passesFilters($route, $only, $except, $config));

        if ($routes->isEmpty()) {
            $this->warn('No routes matched the configured filters. Nothing to generate.');
            return self::SUCCESS;
        }

        $builder = new CollectionBuilder($config);
        $appName = config('app.name', 'Laravel');

        $collection = $builder->build($routes->values(), $appName);

        $collectionPath = $this->resolvePath(
            $this->option('output') ?: ($config['output']['collection'] ?? 'postman/collection.json')
        );
        $this->writeJson($collectionPath, $collection);
        $this->info("✔ Collection written to {$collectionPath} ({$routes->count()} routes)");

        if (!$this->option('no-env')) {
            $environment = $builder->buildEnvironment($appName);
            $envPath = $this->resolvePath($config['output']['environment'] ?? 'postman/environment.json');
            $this->writeJson($envPath, $environment);
            $this->info("✔ Environment written to {$envPath}");
        }

        return self::SUCCESS;
    }

    protected function passesFilters(RouteObj $route, array $only, array $except, array $config): bool
    {
        $uri = $route->uri();
        $name = $route->getName() ?? '';

        if (!empty($only) && !collect($only)->contains(fn ($pattern) => Str::is($pattern, $uri))) {
            return false;
        }

        if (collect($except)->contains(fn ($pattern) => Str::is($pattern, $uri))) {
            return false;
        }

        $exceptNames = $config['routes']['except_name'] ?? [];
        if (!empty($exceptNames) && $name && collect($exceptNames)->contains(fn ($pattern) => Str::is($pattern, $name))) {
            return false;
        }

        $exceptMiddleware = $config['routes']['except_middleware'] ?? [];
        if (!empty($exceptMiddleware)) {
            $middleware = $route->gatherMiddleware();
            if (array_intersect($exceptMiddleware, $middleware)) {
                return false;
            }
        }

        return true;
    }

    protected function resolvePath(string $path): string
    {
        return Str::startsWith($path, ['/', DIRECTORY_SEPARATOR])
            ? $path
            : base_path($path);
    }

    protected function writeJson(string $path, array $data): void
    {
        File::ensureDirectoryExists(dirname($path));
        File::put($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
}
