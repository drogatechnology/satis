<?php

namespace DrogaTechnology\PostmanGenerator\Tests;

use Orchestra\Testbench\TestCase as OrchestraTestCase;
use DrogaTechnology\PostmanGenerator\PostmanGeneratorServiceProvider;

abstract class TestCase extends OrchestraTestCase
{
    protected function getPackageProviders($app): array
    {
        return [PostmanGeneratorServiceProvider::class];
    }

    protected function defineEnvironment($app): void
    {
        $app['config']->set('app.url', 'http://example.test');
    }
}
