<?php

namespace DrogaTechnology\PostmanGenerator\Tests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Route;

class StoreWidgetRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string',
            'email' => 'required|email',
            'quantity' => 'required|integer',
        ];
    }
}

class WidgetController
{
    public function index() {}
    public function store(StoreWidgetRequest $request) {}
}

class GeneratePostmanCollectionTest extends TestCase
{
    protected function defineRoutes($router): void
    {
        $router->get('api/widgets', [WidgetController::class, 'index'])
            ->name('widgets.index');

        $router->post('api/widgets', [WidgetController::class, 'store'])
            ->name('widgets.store')
            ->middleware('auth:sanctum');

        $router->get('web/dashboard', fn () => 'ok')
            ->name('dashboard');
    }

    public function test_it_generates_a_collection_limited_to_configured_routes(): void
    {
        config(['postman-generator.routes.only' => ['api/*']]);
        config(['postman-generator.output.collection' => 'postman/test_collection.json']);

        $this->artisan('postman:generate', ['--no-env' => true])
            ->assertSuccessful();

        $path = base_path('postman/test_collection.json');
        $this->assertFileExists($path);

        $json = json_decode(File::get($path), true);
        $names = collect($json['item'])->pluck('item')->flatten(1)->pluck('name');

        $this->assertTrue($names->contains('widgets.index'));
        $this->assertTrue($names->contains('widgets.store'));
        $this->assertFalse($names->contains('dashboard'), 'web route should be excluded by "only: api/*"');

        File::deleteDirectory(base_path('postman'));
    }

    public function test_it_applies_bearer_auth_for_sanctum_protected_routes(): void
    {
        config(['postman-generator.routes.only' => ['api/*']]);
        config(['postman-generator.output.collection' => 'postman/test_collection.json']);

        $this->artisan('postman:generate', ['--no-env' => true])->assertSuccessful();

        $json = json_decode(File::get(base_path('postman/test_collection.json')), true);
        $items = collect($json['item'])->pluck('item')->flatten(1);

        $store = $items->firstWhere('name', 'widgets.store');
        $index = $items->firstWhere('name', 'widgets.index');

        $this->assertSame('bearer', $store['request']['auth']['type']);
        $this->assertSame('noauth', $index['request']['auth']['type']);

        File::deleteDirectory(base_path('postman'));
    }

    public function test_it_infers_a_sample_body_from_the_form_request_rules(): void
    {
        config(['postman-generator.routes.only' => ['api/*']]);
        config(['postman-generator.output.collection' => 'postman/test_collection.json']);

        $this->artisan('postman:generate', ['--no-env' => true])->assertSuccessful();

        $json = json_decode(File::get(base_path('postman/test_collection.json')), true);
        $items = collect($json['item'])->pluck('item')->flatten(1);
        $store = $items->firstWhere('name', 'widgets.store');

        $body = json_decode($store['request']['body']['raw'], true);

        $this->assertArrayHasKey('name', $body);
        $this->assertArrayHasKey('email', $body);
        $this->assertSame('user@example.com', $body['email']);
        $this->assertSame(1, $body['quantity']);

        File::deleteDirectory(base_path('postman'));
    }
}
