# Laravel Postman Generator

Generate a **Postman Collection v2.1** (plus a matching environment file) straight from your app's registered routes — one artisan command, no manual clicking-through in Postman.

## Features

- Walks `Route::getRoutes()` and builds a full Postman collection
- **Smart body inference**: reflects on a route's type-hinted `FormRequest::rules()` and generates a realistic sample JSON body (`email` rule → `user@example.com`, `integer` → `1`, `in:foo,bar` → `foo`, etc.)
- **Auth-aware**: maps route middleware (`auth:sanctum`, `auth:api`, custom guards) to the correct Postman auth block (`bearer`, `basic`, `apikey`, or `noauth`) per request — no more hand-editing every request's auth tab
- Generates a companion **environment file** with `base_url` and token/apikey variables pre-wired
- Configurable route filtering (include/exclude by URI pattern, route name, or middleware)
- Configurable grouping into Postman folders (by URI prefix, by controller, or flat)
- Zero runtime footprint — this is a `dev`-time console command only

## Installation

This is a private package hosted under the [drogatechnology](https://github.com/drogatechnology) GitHub org. In the consuming project's `composer.json`, add it as a VCS repository:

```json
"repositories": [
    {
        "type": "vcs",
        "url": "https://github.com/drogatechnology/postman-generator"
    }
]
```

Then require it:

```bash
composer require drogatechnology/postman-generator --dev
```

Composer needs a GitHub token with read access to the private repo (`composer config --global github-oauth.github.com <token>`) — see the internal setup notes for the org's shared token/CI secret.

Laravel's package auto-discovery will register the service provider. Publish the config if you want to customize behavior:

```bash
php artisan vendor:publish --tag=postman-generator-config
```

## Usage

```bash
php artisan postman:generate
```

This writes:

- `postman/collection.json` — import directly into Postman
- `postman/environment.json` — import and select it as your active environment

### Common options

```bash
# Only include a subset of routes for this run
php artisan postman:generate --only="api/v1/*"

# Exclude a pattern for this run
php artisan postman:generate --except="api/internal/*"

# Skip the environment file
php artisan postman:generate --no-env

# Write the collection somewhere else
php artisan postman:generate --output=storage/app/collection.json
```

## Configuration

See [`config/postman-generator.php`](config/postman-generator.php) for the full set of options. Highlights:

```php
'routes' => [
    'only' => ['api/*'],          // only these URI patterns
    'except' => [],                 // exclude these
    'except_middleware' => ['throttle'], // skip routes carrying this middleware
],

'auth' => [
    'default' => 'noauth',
    'middleware_map' => [
        'auth:sanctum' => 'bearer',
        'auth:api' => 'bearer',
    ],
],

'infer_body_from_form_requests' => true,

'grouping' => 'prefix', // 'prefix' | 'controller' | 'none'
```

### How body inference works

If a route's controller method (or closure) type-hints a `FormRequest`, the generator instantiates it, reads `rules()`, and builds a sample JSON body:

```php
// StoreOrderRequest::rules()
[
    'customer_email' => 'required|email',
    'quantity' => 'required|integer',
    'status' => 'required|in:pending,paid',
]

// generated body
{
    "customer_email": "user@example.com",
    "quantity": 1,
    "status": "pending"
}
```

Nested (`items.*.sku`) and array rules are supported. When no `FormRequest` is found, or `infer_body_from_form_requests` is `false`, an empty `{}` body is used instead.

### How auth resolution works

Each route's `gatherMiddleware()` is checked against `auth.middleware_map`. The first match wins and determines the request's Postman `auth` block; unmatched routes fall back to `auth.default`. This means a `Bearer {{token}}` header is attached automatically to authenticated endpoints and omitted from public ones — no manual per-request auth setup in Postman.

## Releasing a new version

Tag and push as normal:

```bash
git tag v1.1.0
git push origin v1.1.0
```

`.github/workflows/notify-satis.yml` fires on that tag push and pings [drogatechnology/satis](https://github.com/drogatechnology/satis) to rebuild its index immediately, so the new version is installable within seconds rather than waiting on Satis's scheduled rebuild. This requires the `SATIS_DISPATCH_TOKEN` secret to be set on this repo (or inherited from an org-level secret) — see the satis repo's README for how that token is generated.

## Testing

```bash
composer install
vendor/bin/phpunit
```

Tests use [Orchestra Testbench](https://github.com/orchestral/testbench) to boot a minimal Laravel app, register the package, define a couple of test routes/FormRequests, and assert on the generated JSON.

## Roadmap ideas

- Optional live "hit each route and save the response as a Postman example" mode
- OpenAPI/Swagger import as an alternative source of truth
- Per-route response schema assertions

## License

MIT
